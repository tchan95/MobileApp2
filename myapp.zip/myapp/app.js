var express = require('express');
var app = express();

var bodyParser = require("body-parser");

var mysql = require('mysql');
var pool = mysql.createPool({
                            connectionLimit : 10,
                            host: 'localhost',
                            user: 'root',
                            password:'database',
                            database:'knu'
                            });

app.use(bodyParser.urlencoded({extended: false}));
var data = {'result':1}
app.get('/', function (req, res) {
        res.send('Hello World');
        });
app.post('/login', function(req, res, next){
         if(req.body.id == "" && req.body.pw == ""){
            res.status(500).end("invalid id or passwprd");
            console.log('login post error:', );
         }else{
             var id = req.body.id;
             var pw = req.body.pw;
             var sql = 'SELECT S_ID ,NAME, state from user where ' + 'id=\"' + id +'\"' +' and '+ 'pw=\"' + pw + '\"';
             pool.getConnection(function(err, connection){
                                connection.query(sql, function(err, rows, fields) {
                                                 if (err){
                                                    console.log('login post error:', err);
                                                    //res.status(500).end("query error");
                                                    res.status(500).end("empty set");
                                                 }else{
                                                    if(rows.length != 0){
                                                        console.log("usr info:",rows);
                                                        res.writeHead(200,{'Content-Type':'application/json'});
                                                        res.end(JSON.stringify(rows));
                                                 /*
                                                    if(rows.length != 0){
                                                        console.log(rows);
                                                        if(rows[0].state == 0){
                                                            res.end("0");
                                                        }else{
                                                            res.end("1");
                                                        }*/
                                                    }else{
                                                        console.log("error");
                                                        res.status(500).end("invalid id or passwprd");
                                                    }
                                                 }
                                           });
                                connection.release();
                            });
             }
         });
app.get('/building_user', function(req,res){
        pool.getConnection(function(err,connection){
                           connection.query('select DPT,DPT_NAME,ROOM from building;', function(err, rows, fields) {
                                            if (err){
                                                console.log('building get error:', err);
                                                res.status(500).end("query error");
                                            }else{
                                                if(rows.length == 0){
                                                    res.status(500).end("empty set");
                                                }else{
                                                    console.log("buildings:",rows);
                                                    res.writeHead(200,{'Content-Type':'application/json'});
                                                    res.end(JSON.stringify(rows));
                                                }
                                            }
                                        });
                           connection.release();
                        });
        });
app.get('/building_mg', function(req,res){
        pool.getConnection(function(err,connection){
                           connection.query('select B_ID, B_NUM, DPT, DPT_NAME, FLOOR, ROOM, M_ID from building;', function(err, rows, fields) {
                                            if (err){
                                            console.log('building get error:', err);
                                            res.status(500).end("query error");
                                            }else{
                                            if(rows.length == 0){
                                            res.status(500).end("empty set");
                                            }else{
                                            console.log("buildings:",rows);
                                            res.writeHead(200,{'Content-Type':'application/json'});
                                            res.end(JSON.stringify(rows));
                                            }
                                            }
                                            });
                           connection.release();
                           });
        });
app.post('/building_mg_delete', function(req, res){
          var b_id = req.body.B_ID
          console.log(b_id)
//         var delete_sql = 'update building set b_state = -1 where b_id = ?;' // for test
          var delete_sql = 'delete from building where b_id = ?;' // it works well
          pool.getConnection(function(err,connection){
                             connection.query(delete_sql,[b_id] ,function(err, rows, fields){
                                              if (err){
                                              console.log('[+]rbuilding_mg_delete post error:', err);
                                              res.status(500).end(err)
                                              }else{
                                              console.log('[+]building_mg_delete post : OK');
                                              res.end("OK")
                                              }
                                              });
                             connection.release();
                             });
          });
app.post('/building_mg_insert', function(req, res){
         var b_num = req.body.B_NUM
         var dpt = req.body.DPT
         var dpt_name = req.body.DPT_NAME
         var floor = req.body.FLOOR
         var room = req.body.ROOM
         var m_id = req.body.M_ID
         var insert_sql = 'insert into building(B_NUM, DPT, DPT_NAME, FLOOR, ROOM) VALUES(?, ?, ?, ?, ?);' // it works well
         pool.getConnection(function(err,connection){
                            connection.query(insert_sql, [ b_num, dpt, dpt_name, floor, room],function(err, rows, fields){
                                             if (err){
                                             console.log('[+]building_mg_insert post error:', err);
                                             res.status(500).end(err)
                                             }else{
                                             console.log('[+]reservation/mg/denied post : OK');
                                             res.end("OK")
                                             }
                                             });
                            connection.release();
                            });
         });
app.post('/building_mg_update', function(req, res){
         var b_id = req.body.B_ID
         var b_num = req.body.B_NUM
         var dpt = req.body.DPT
         var dpt_name = req.body.DPT_NAME
         var floor = req.body.FLOOR
         var room = req.body.ROOM
         var m_id = req.body.M_ID
         var update_sql = 'update building set B_NUM = ?, DPT = ?, DPT_NAME = ?, FLOOR = ?, ROOM = ?, M_ID = ? where B_ID = ? ;' // it works well
         console.log(b_id)
         pool.getConnection(function(err,connection){
                            connection.query(update_sql, [b_num, dpt, dpt_name, floor, room, m_id, b_id],function(err, rows, fields){
                                             if (err){
                                             console.log('[+]building_mg_update post error:', err);
                                             res.status(500).end(err)
                                             }else{
                                             console.log('[+]building_mg_update post : OK');
                                             res.end("OK")
                                             }
                                             });
                            connection.release();
                            });
         });
app.post('/reservation/check', function(req, res){
        
        var s_id = req.body.S_ID;
        var name = req.body.NAME;
        var sql = 'select NUM, S_ID, NAME, DPT, DPT_NAME, ROOM, DATE, S_TIME, F_TIME, STATE from reservation where s_id = '+ s_id +';'
        pool.getConnection(function(err,connection){
                           connection.query(sql, function(err, rows, fields){
                               if (err){
                                     console.log('reservation get error:', err);
                                     res.status(500).end("query error");
                               }else{
                                     if(rows.length == 0){
                                        console.log('empty set:',s_id, name);
                                        res.status(500).end("empty set");
                                     }else{
                                        console.log("reservation:",rows);
                                        res.writeHead(200,{'Content-Type':'application/json'});
                                        res.end(JSON.stringify(rows));
                                     }
                               }
                            });
                           connection.release();
                        });
        });
app.post('/reservation/cancel', function(req, res){
         var r_num = req.body.NUM
         console.log(r_num)
         var delete_sql = 'delete from reservation where NUM = ?;'
         pool.getConnection(function(err,connection){
                            connection.query(delete_sql,[r_num] ,function(err, rows, fields){
                                             if (err){
                                             console.log('[+]reservation_delete post error:', err);
                                             res.status(500).end(err)
                                             }else{
                                             console.log('[+]reservation_delete post : OK');
                                             res.end("OK")
                                             }
                                             });
                            connection.release();
                            });
         });
app.post('/reservation/insert', function(req, res){
         var dpt = req.body.DPT;
         var dpt_name = req.body.DPT_NAME;
         var room = req.body.ROOM;
         var s_id = req.body.S_ID;
         var name = req.body.NAME;
         var s_time = req.body.S_TIME;
         var f_time = req.body.F_TIME;
         var date = req.body.DATE;
         var insert_sql = 'INSERT INTO RESERVATION(DPT, DPT_NAME, ROOM, S_ID, NAME, S_TIME, F_TIME, DATE) VALUES(?,?,?,?,?,?,?,?);';
         var select_sql = 'select * from reservation where ((? <= s_time and s_time <  ? and ? <= f_time) or (s_time <= ? and ? < f_time and f_time < ?) or ( ? <= s_time and f_time <= ?)) and dpt = ? and dpt_name = ? and room = ? and date(DATE) = ? and (state = 0 or state = 1);';
         
         //console.log(insert_sql)
         pool.getConnection(function(err, connection){
                            connection.query(select_sql,[s_time, f_time, f_time,   s_time, s_time, f_time,  s_time, f_time,  dpt, dpt_name, room, date],function(err, rows, fields) {
                                             if(err){
                                                console.log('[+]', select_sql,' error : ', err);
                                                res.status(500).end(err)
                                             }else{
                                                if(rows.length == 0){
                                                    connection.query(insert_sql,[dpt, dpt_name, room, s_id, name, s_time, f_time, date],function(err, rows, fields) {
                                                                                                           if (err){
                                                                                                           console.log('reservation/insert post error:', err);
                                                                                                           res.status(500).end(err)
                                                                                                           }else{
                                                                                                            console.log('reservation/insert post : OK');
                                                                                                            res.end("OK")
                                                                                                           }
                                                                                                           });
                                                }else{
                                                    console.log("[+]pre-query:", 'there has been the reservation of the same location');
                                                    res.status(500).end("there has been the reservation of the same location");
                                                }
                                             }
                            });
                            });
//         pool.getConnection(function(err, connection){
//                            connection.query(sql,[dpt, dpt_name, room, s_id, name, s_time, f_time, date],function(err, rows, fields) {
//                                             if (err){
//                                             console.log('login post error:', err);
//                                             res.states(500).end(err);
//                                             }else{
//                                             if(rows.length != 0){
//                                             console.log("usr info:",rows);
//                                             res.writeHead(200,{'Content-Type':'application/json'});
//                                             res.end(JSON.stringify(rows));
//                                             }else{
//                                             console.log("error");
//                                             res.status(500).end("invalid info");
//                                             }
//                                             }
//                                             });
//                            connection.release();
//                            });
         });
app.get('/reservation/mg/query', function(req, res){
        var sql = 'select NUM, S_ID, NAME, DPT, DPT_NAME, ROOM, DATE, S_TIME, F_TIME, STATE from reservation;'
        pool.getConnection(function(err,connection){
                           connection.query(sql, function(err, rows, fields){
                                            if (err){
                                            console.log('reservation get error:', err);
                                            res.status(500).end("query error");
                                            }else{
                                            if(rows.length == 0){
                                            console.log('empty set:');
                                            res.status(500).end("empty set");
                                            }else{
                                            console.log("reservation:",rows);
                                            res.writeHead(200,{'Content-Type':'application/json'});
                                            res.end(JSON.stringify(rows));
                                            }
                                            }
                                            });
                           connection.release();
                           });
        });
app.post('/reservation/mg/denied', function(req, res){
         var num = req.body.NUM
         console.log(num)
         var update_sql = 'update reservation set state = -1 where num = ?;'
         pool.getConnection(function(err,connection){
                            connection.query(update_sql,[num] ,function(err, rows, fields){
                                             if (err){
                                             console.log('/reservation/mg/denied post error:', err);
                                             res.status(500).end(err)
                                             }else{
                                             
                                             console.log('/reservation/mg/denied post : OK');
                                             res.end("OK")
                                             }
                                             });
                            connection.release();
                            });
         });
app.post('/reservation/mg/permission', function(req, res){
         var num = req.body.NUM
         console.log(num)
         var update_sql = 'update reservation set state = 1 where num = ?;'
         pool.getConnection(function(err,connection){
                            connection.query(update_sql,[num] ,function(err, rows, fields){
                                             if (err){
                                             console.log('/reservation/mg/denied post error:', err);
                                             res.status(500).end(err)
                                             }else{
                                             console.log('/reservation/mg/permission post : OK');
                                             res.end("OK")
                                             }
                                             });
                            connection.release();
                            });
         });
app.get('/login', function (req, res){
        /*
         0: user
         1: manager
         -1: false
         */
        console.log("log web requirement");
        res.writeHead(200,{'Content-Type':'application/json'});
        res.end(JSON.stringify(data));
        });


/*
app.get('/login/url2', function (req, res){
        console.log("log web requirement");
        res.send('Hello Get route/2');
        });
*/
var server = app.listen(8081, function () {
                        var host = server.address().address
                        var port = server.address().port
                        console.log("应用实例，访问地址为 http://%s:%s", host, port)
                        })
